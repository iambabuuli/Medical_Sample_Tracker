<?php
require_once 'config.php';


if($connection){

    $sql = "SELECT * FROM registered_samples";

    $respons = mysqli_query($connection, $sql);

    $result = array();
    $result['registered_samples'] = array();

    if(mysqli_num_rows($respons)){

       while($row = mysqli_fetch_assoc($respons)){

            $index['sample_id'] = $row['sample_id'];
            $index['patient_id'] = $row['patient_id'];
            $index['first_name'] = $row['first_name'];
            $index['last_name'] = $row['last_name'];
            $index['date_of_birth'] = $row['date_of_birth'];
            $index['gender'] = $row['gender'];
            $index['address'] = $row['address'];
            $index['age'] = $row['age'];
            $index['hospital_number'] = $row['hospital_number'];
            $index['phone_number'] = $row['phone_number'];
            $index['email'] = $row['email'];
            $index['hospital_patient'] = $row['hospital_patient'];
            $index['suspected_disease'] = $row['suspected_disease'];
            $index['sample_type'] = $row['sample_type'];
            $index['clinical_information'] = $row['clinical_information'];
            $index['next_of_kin'] = $row['next_of_kin'];
            $index['expected_date_of_return'] = $row['expected_date_of_return'];
            $index['is_sample_received'] = $row['is_sample_received'];
            $index['results'] = $row['results'];
            $index['date_registered'] = $row['date_registered'];
            $index['registered_by'] = $row['registered_by'];
            $index['paid'] = $row['paid'];
            $index['received_by'] = $row['received_by'];
            $index['lab_notes'] = $row['lab_notes'];
            $index['registers_phone_number'] = $row['registers_phone_number'];
            $index['receivers_phone_number'] = $row['receivers_phone_number'];

            array_push($result['registered_samples'], $index);
       }
            
            $result['success'] = "1";
            $result['message'] = "Success";
    
            echo json_encode($result);

            mysqli_close($connection);
          
        }else {

            $result['success'] = "1";
            $result['message'] = "Cannot create list.";
    
            echo json_encode($result);

            mysqli_close($connection);

        }
    }

?>
