<?php

require_once 'config.php';

//Update the records for the registered samples
if($_SERVER['REQUEST_METHOD'] == 'POST'){

    $specimen_id = $_POST['sample_id'];
    $patients_Id_number = $_POST['patients_Id_number'];
    $patients_surname = $_POST['patients_surname'];
    $patients_firstName = $_POST['patients_firstName'];
    $patients_date_of_birth = $_POST['patients_date_of_birth'];
    $patients_phone_number = $_POST['patients_phone_number'];
    $patients_email = $_POST['patients_email'];
    $hospital_or_folio_number = $_POST['hospital_or_folio_number'];
    $patients_address = $_POST['patients_address'];
    $patients_age = $_POST['patients_age'];
    $suspected_disease = $_POST['suspected_disease'];
    $next_of_kin = $_POST['next_of_kin'];
    $clinical_or_drug_information = $_POST['clinical_or_drug_information'];
    $expected_date_of_return = $_POST['expected_date_of_return'];
    
   
    $sql = "UPDATE `registered_samples` SET `sample_id`= '$specimen_id', `patient_id`= '$patients_Id_number', `first_name`= '$patients_surname', `last_name`= '$patients_firstName', `date_of_birth`= '$patients_date_of_birth', `address`= '$patients_address', `age`= '$patients_age',`hospital_number`= '$hospital_or_folio_number', `phone_number`= '$patients_phone_number', `email` = '$patients_email', `suspected_disease` = '$suspected_disease', `next_of_kin` = '$next_of_kin',`clinical_information`= '$clinical_or_drug_information', `expected_date_of_return` = '$expected_date_of_return' WHERE `sample_id`= '$specimen_id' ";

    if(mysqli_query($connection, $sql)){

        $result["success"] = "1";
        $result["message"] = "Successfull";

        echo json_encode($result);
        mysqli_close($connection);

    }else{

        $result["success"] = "0";
        $result["message"] = "Error";

        echo json_encode($result);
        mysqli_close($connection);

    }
}

?>