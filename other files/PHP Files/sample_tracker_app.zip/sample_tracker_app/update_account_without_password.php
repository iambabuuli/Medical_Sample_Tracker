<?php 

require_once 'config.php';

//This will run if the user updates account information with out password 
if($_SERVER['REQUEST_METHOD'] == 'POST'){

	$first_name = $_POST['first_name'];
	$last_name = $_POST['last_name'];
	$email = $_POST['email'];
	$phone_number = $_POST['phone_number'];
	$encoded_photo = $_POST['encoded_image'];
    $image_name = $_POST['image_name'];

    $image_path = "profile_pictures/".$image_name;

    $final_image_path = $address."sample_tracker_app/".$image_path;

    $get_current_image_path = "SELECT profile_picture_path FROM users WHERE email = '$email'";

    $get_current_image_path_sql = mysqli_query($connection, $get_current_image_path);

    if(mysqli_num_rows($get_current_image_path_sql) === 1){

    $row = mysqli_fetch_assoc($get_current_image_path_sql);

    if(file_exists($row['profile_picture_path'])){

    	unlink($row['profile_picture_path']);

    if(file_put_contents($image_path, base64_decode($encoded_photo))){

    $sql = " UPDATE `users` SET `first_name`= '$first_name',`last_name`= '$last_name',`email`= '$email',`phone_number`= '$phone_number', `profile_picture_path`= '$image_path',`profile_picture_address`= '$final_image_path' WHERE email = '$email'";

	if (mysqli_query($connection, $sql)) {

			$result['success'] = "1";
			$result['message'] = "Account updated.";
			echo json_encode($result);
			mysqli_close($connection);

	}else{

		$result['success'] = "0";
		$result['message'] = "Failed to update account.";
		echo json_encode($result);
		mysqli_close($connection);
	}

    } else {

    	$result['success'] = "0";
		$result['message'] = "Failed to update profile picture.";
		echo json_encode($result);
		mysqli_close($connection);

    }

    } else {

    	$result['success'] = "0";
		$result['message'] = "Current profile picture does not exist.";
		echo json_encode($result);
		mysqli_close($connection);

    	}

    } else {

    	$result['success'] = "0";
		$result['message'] = "Cannot not access the current profile picture.";
		echo json_encode($result);
		mysqli_close($connection);
    }
}

?>