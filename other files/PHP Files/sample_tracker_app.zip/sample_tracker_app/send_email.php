<?php     


$to_email = '256704949865@vtext.com';

$subject = 'Hello this is a php email test.';

$message = 'This mail is sent using the PHP mail function';

$headers = 'From: tumusiimejoshua47@gmail.com';

mail($to_email,$subject,$message,$headers);


?>
