<?php
require_once 'config.php';


if($_SERVER['REQUEST_METHOD'] == 'POST'){

    $sql = "SELECT * FROM payment_of_account";

    $respons = mysqli_query($connection, $sql);

    $result = array();
    $result['payment_of_account'] = array();

    if(mysqli_num_rows($respons)){

       while($row = mysqli_fetch_assoc($respons)){

            $index['patient_id'] = $row['patient_id'];
            $index['national_id_number'] = $row['national_id_number'];
            $index['first_name'] = $row['first_name'];
            $index['last_name'] = $row['last_name'];
            $index['title'] = $row['title'];
            $index['postal_address'] = $row['postal_address'];
            $index['phone_number'] = $row['phone_number'];
            $index['email'] = $row['email'];
            $index['employer'] = $row['employer'];
            $index['medical_aid_name'] = $row['medical_aid_name'];
            $index['cash_receipt_number'] = $row['cash_receipt_number'];
            $index['date_payed'] = $row['date_payed'];

            array_push($result['payment_of_account'], $index);
       }
            
            $result['success'] = "1";
            $result['message'] = "Success";
            echo json_encode($result);
            mysqli_close($connection);
          
        }
        
    } else {

        $result['success'] = "0";
        $result['message'] = "Cannot retrive data.";
    
        echo json_encode($result);
        mysqli_close($connection);

    }

?>
