<?php 

require_once 'config.php';

 //Change the user previleges 
    if($_SERVER['REQUEST_METHOD'] == 'POST'){

        $email = $_POST['email'];
        $account_type = $_POST['account_type'];
        $type_of_worker = $_POST['type_of_worker'];

        $sql = "UPDATE users SET account_type = '$account_type' ,type_of_worker = '$type_of_worker' WHERE email = '$email'";

        if(mysqli_query($connection, $sql)){

            $result['success'] = "1";
            $result['message'] = "Account has been updated.";
            echo json_encode($result);
            mysqli_close($result);

        }else{

            $result['success'] = "0";
            $result['message'] = "Failed to update account.";
            echo json_encode($result);
            mysqli_close($connection);

        }
    }
?>