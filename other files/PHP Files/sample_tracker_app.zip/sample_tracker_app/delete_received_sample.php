<?php 

require_once 'config.php';

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    
    $id = $_POST['id'];
    
    $sql = "DELETE FROM received_samples WHERE sample_id = '$id'";

    $updateRegisteredSample = "UPDATE `registered_samples` SET `is_sample_received`= 'No', `results` = '', `received_by`= '',`lab_notes`= '', `receivers_phone_number`= '' WHERE `sample_id` = '$id'";

    if(mysqli_query($connection, $updateRegisteredSample)){

        if(mysqli_query($connection, $sql)){

        $result["success"] = "1";
        $result["message"] = "Successfull";

        echo json_encode($result);
        mysqli_close($connection);

    }else{

        $result["success"] = "0";
        $result["message"] = "Error";

        echo json_encode($result);
        mysqli_close($connection);

    }

    }else{

        $result["success"] = "0";
        $result["message"] = "Error";

        echo json_encode($result);
        mysqli_close($connection);

    }

}

?>