<?php 

require_once 'config.php';

//Update records of the received samples 

if($_SERVER['REQUEST_METHOD'] == 'POST'){

    $specimen_id = $_POST['sample_id'];
    $sample_status = $_POST['sample_status'];
    $results = $_POST['results'];
    $lab_notes = $_POST['lab_notes'];
   
    //Update the records for the received samples
    $sql = "UPDATE received_samples SET sample_id = '$specimen_id', sample_status = '$sample_status' , results = '$results', lab_notes = '$lab_notes' WHERE sample_id = '$specimen_id'";

    if( mysqli_query($connection, $sql)){

    //Update records for the registered samples 
    $updateRegisteredSamples = " UPDATE registered_samples SET results = '$results', lab_notes = '$lab_notes' WHERE sample_id = '$specimen_id'";

        if(mysqli_query($connection, $updateRegisteredSamples)){

        $result["success"] = "1";
        $result["message"] = "Records have been updated Successfully.";

        echo json_encode($result);
        mysqli_close($connection);

        } else {

        $result["success"] = "0";
        $result["message"] = "Failed to update records.";

        echo json_encode($result);
        mysqli_close($connection);

        }

    }else{

        $result["success"] = "0";
        $result["message"] = "Error";

        echo json_encode($result);
        mysqli_close($connection);

    }
    
    }
?>