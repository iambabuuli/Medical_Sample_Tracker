<?php

 require_once'config.php';

if($_SERVER['REQUEST_METHOD'] == 'POST'){

    $sample_id = $_POST['sample_id'];
    $sample_status = $_POST['sample_status'];
    $received_by = $_POST['received_by'];
    $results = $_POST['results'];
    $lab_notes = $_POST['lab_notes'];
    $receivers_phone_number = $_POST['receivers_phone_number'];
    

    //Retrieve needed information from registered samples.
    $receiveDataFromRegisteredSamples = "SELECT sample_id, patient_id, suspected_disease, sample_type, registered_by, registers_phone_number FROM registered_samples WHERE sample_id = '$sample_id'";
    
    $registeredSamplesData = mysqli_query($connection, $receiveDataFromRegisteredSamples);

    //Check to see if the sample id provided exists
    if(mysqli_num_rows($registeredSamplesData) === 1){

        $row = mysqli_fetch_assoc($registeredSamplesData);

        $registered_sample_id = $row['sample_id'];
        $registered_patient_id = $row['patient_id'];
        $registered_suspected_disease = $row['suspected_disease'];
        $registered_sample_type = $row['sample_type'];
        $registered_registered_by = $row['registered_by'];
        $registered_registers_phone_number = $row['registers_phone_number'];

        $insertIntoReceivedSamples = "INSERT INTO `received_samples`(`sample_id`, `patient_id`, `suspected_disease`, `sample_type`, `sample_status`, `results`, `lab_notes`, `registered_by`, `received_by`, `registers_phone_number`, `receivers_phone_number`) VALUES ('$sample_id', '$registered_patient_id', '$registered_suspected_disease', '$registered_sample_type', '$sample_status', '$results', '$lab_notes', '$registered_registered_by', '$received_by', '$registered_registers_phone_number', '$receivers_phone_number')";

    //Insert data into received samples
    if( mysqli_query($connection, $insertIntoReceivedSamples)){

     $updateRegisteredSample = "UPDATE `registered_samples` SET `is_sample_received`= 'Yes',`results` = '$results', `received_by`= '$received_by',`lab_notes`= '$lab_notes', `receivers_phone_number`= '$receivers_phone_number' WHERE `sample_id` = '$sample_id'";
    
    //Update the records for received samples.
    if(mysqli_query($connection, $updateRegisteredSample)){
        
        $result["success"] = "1";
        $result["message"] = "Sample has been received Successfully.";
        echo json_encode($result);
        mysqli_close($connection);

    //Retun an error if failed to update records for registered samples  
    }else{
    
        $result["success"] = "0";
        $result["message"] = "Failed to receive samples.";

        echo json_encode($result);
        mysqli_close($connection);
         
    }

    //Return error if failed to to insert data into received samples
    }else{

        $result["success"] = "0";
        $result["message"] = "Cannot receive sample data.";

        echo json_encode($result);
        mysqli_close($connection);

    }

    //Return an error if the records for the sample id searched for in registered 
    //samples does not exist.
    }else {

        $result["success"] = "0";
        $result["message"] = "The sample id you provided does not exist.";
        echo json_encode($result);
        mysqli_close($connection);

    }

   
}


?>
