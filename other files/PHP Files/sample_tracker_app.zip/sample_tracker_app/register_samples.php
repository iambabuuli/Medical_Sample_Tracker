<?php

require_once 'config.php';

if($_SERVER['REQUEST_METHOD'] == 'POST'){

    $sample_id = $_POST['sample_id'];
    $patient_id = $_POST['patient_id'];
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $date_of_birth = $_POST['date_of_birth'];
    $gender = $_POST['gender'];
    $address = $_POST['address'];
    $age = $_POST['age'];
    $hospital_number = $_POST['hospital_number'];
    $phone_number = $_POST['phone_number'];
    $email = $_POST['email'];
    $hospital_patient = $_POST['hospital_patient'];
    $suspected_disease = $_POST['suspected_disease'];
    $sample_type = $_POST['sample_type'];
    $next_of_kin = $_POST['next_of_kin'];
    $clinical_information = $_POST['clinical_information'];
    $expected_date_of_return = $_POST['expected_date_of_return'];
    $registered_by = $_POST['registered_by'];
    $registers_phone_number = $_POST['registers_phone_number'];


    // $sample_id = "0007";
    // $patient_id = "000000";
    // $first_name = "Jeff";
    // $last_name = "Jason";
    // $date_of_birth = "2020-6-25";
    // $gender = "Male";
    // $address = "Kiwempe";
    // $age = "25";
    // $hospital_number = "2233";
    // $phone_number = "0772463134";
    // $email = "waknoyd@gmail.com";
    // $hospital_patient = "Yes";
    // $suspected_disease = "Malaria";
    // $sample_type = "Blood";
    // $next_of_kin = "James";
    // $clinical_information = "None";
    // $expected_date_of_return = "2020-6-25";
    // $registered_by = "Tumusiime Joshua";
    // $registers_phone_number = "0772323456";
    
    
    $sql = "INSERT INTO `registered_samples` (`sample_id`, `patient_id`, `first_name`, `last_name`, `date_of_birth`, `gender`, `address`, `age`, `hospital_number`, `phone_number`, `email`, `hospital_patient`, `suspected_disease`, `sample_type`, `next_of_kin`, `clinical_information`, `expected_date_of_return`, `is_sample_received`, `results`, `date_registered`, `registered_by`, `paid`, `received_by`, `lab_notes`, `registers_phone_number`, `receivers_phone_number`) VALUES ('$sample_id', '$patient_id', '$first_name', '$last_name', '$date_of_birth', '$gender', '$address', '$age', '$hospital_number', '$phone_number', '$email', '$hospital_patient', '$suspected_disease', '$sample_type', '$next_of_kin', '$clinical_information', '$expected_date_of_return', 'No', 'Pending', current_timestamp(), '$registered_by', 'No', '', '', '$registers_phone_number', '')";

    if(mysqli_query($connection, $sql)){

        $result["success"] = "1";
        $result["message"] = "Successfull";

        echo json_encode($result);
        mysqli_close($connection);

    }else{

        $result["success"] = "0";
        $result["message"] = "Error, cannot register data.";

        echo json_encode($result);
        mysqli_close($connection);

    }
}
?>
