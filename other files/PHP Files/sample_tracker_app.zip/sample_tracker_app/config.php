<?php

$address = "localhost";
$user_name = "wenzotek_root";
$password = "wenzotek@2022";
$database = "wenzotek_sample_tracker";

$connection = mysqli_connect($address, $user_name, $password, $database);

$address = "http://wenzotek.com/projects/api/sample_tracker_app/";

?>
