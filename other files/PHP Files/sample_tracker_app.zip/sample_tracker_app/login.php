<?php
require_once 'config.php';


if($_SERVER['REQUEST_METHOD'] == 'POST'){

    $email = $_POST['email'];
    $password = $_POST['password'];

    // $email = "waknoyd@gmail.com";
    // $password = "Surge98Betasux#";

    $sql = "SELECT * FROM users WHERE email = '$email'";

    $respons = mysqli_query($connection, $sql);

    $result = array();
    $result['login'] = array();

    if(mysqli_num_rows($respons) === 1){

        $row = mysqli_fetch_assoc($respons);
        
        // password_verify($password, $row['password'])

        if(password_verify($password, $row['password'])){
    
            $index['first_name'] = $row['first_name'];
            $index['last_name'] = $row['last_name'];
            $index['email'] = $row['email'];
            $index['phone_number'] = $row['phone_number'];
            $index['account_type'] = $row['account_type'];
            $index['profile_picture_path'] = $row['profile_picture_path'];
            
            array_push($result['login'], $index);
    
            $result['success'] = "1";
            $result['message'] = "Log In is successfull.";
    
            echo json_encode($result);

            mysqli_close($connection);

        } 

        else{

            $result['success'] = "0";
            $result['message'] = "Password provided is invalid.";
            echo json_encode($result);
            mysqli_close($connection);
        }
        
        } else{
            $result['success'] = "0";
            $result['message'] = "E-maill provided is invalid.";
    
            echo json_encode($result);
            mysqli_close($connection);
    }

   
}
?>
