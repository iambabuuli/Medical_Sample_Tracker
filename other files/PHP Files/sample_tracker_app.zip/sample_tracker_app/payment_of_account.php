<?php

require_once 'config.php';

if($_SERVER['REQUEST_METHOD'] == 'POST'){

    $patients_id_number = $_POST['patients_id_number'];
    $id_number = $_POST['id_number'];
    $surname = $_POST['surname'];
    $first_name = $_POST['first_name'];
    $title = $_POST['title'];
    $postal_address = $_POST['postal_address'];
    $telephone_number = $_POST['telephone_number'];
    $email= $_POST['email'];
    $employer = $_POST['employer'];
    $medical_aid_name = $_POST['medical_aid_name'];
    $cash_receipt_number = $_POST['cash_receipt_number'];

   
   $get_Patient_Id_Number = "SELECT patient_id FROM registered_samples WHERE patient_id = '$patients_id_number' ";

   $get_Patient_Id_Number_sql = mysqli_query($connection, $get_Patient_Id_Number);

   if(mysqli_num_rows($get_Patient_Id_Number_sql) > 0){

        $updateRegisteredSamples = "UPDATE `registered_samples` SET `paid`= 'Yes' WHERE patient_id = '$patients_id_number'";

    if(mysqli_query($connection, $updateRegisteredSamples)){

    $sql = "INSERT INTO `payment_of_account`(`patient_id`, `national_id_number`, `first_name`, `last_name`, `title`, `postal_address`, `phone_number`, `email`, `employer`, `medical_aid_name`, `cash_receipt_number`) VALUES ('$patients_id_number', '$id_number', '$surname', '$first_name', '$title', '$postal_address', '$telephone_number', '$email', '$employer', '$medical_aid_name', '$cash_receipt_number')";

    if( mysqli_query($connection, $sql)){
        $result["success"] = "1";
        $result["message"] = "Successfull";
        echo json_encode($result);
        mysqli_close($connection);

    } else {

        $result["success"] = "0";
        $result["message"] = "Error on creating cash receipt.";
        echo json_encode($result);
        mysqli_close($connection);

    }

   } else {

        $result["success"] = "0";
        $result["message"] = "Patient Id does not exist.";
        echo json_encode($result);
        mysqli_close($connection);

    }

   } else {

        $result["success"] = "0";
        $result["message"] = "Patient id does not exist.";
        echo json_encode($result);
        mysqli_close($connection);

   }

}

?>
