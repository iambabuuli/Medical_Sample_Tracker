<?php
require_once '../config.php';


if($connection){

    $results = $_POST['results'];
    $address = $_POST['address'];

    // $results = "Kamwokya";
    // $address = "Pending";

    $sql = "SELECT `suspected_disease`, count(`address`) AS 'address_counts' FROM `registered_samples` WHERE `results` = '$results' AND `address` = '$address' GROUP BY `suspected_disease` ORDER BY 'address_counts'";


    $respons = mysqli_query($connection, $sql);

    $result = array();
    $result['suspected_disease'] = array();

    if(mysqli_num_rows($respons)){

       while($row = mysqli_fetch_assoc($respons)){

            $index['suspected_disease'] = $row['suspected_disease'];
            $index['address_counts'] = intval($row['address_counts']);
            $index['address_count'] = 5;
           
            array_push($result['suspected_disease'], $index);
       }
            
            $result['success'] = "1";
            $result['message'] = "Success";
            echo json_encode($result);
            mysqli_close($connection);
          
        }else {

            $result['success'] = "1";
            $result['message'] = "Cannot create list.";
    
            echo json_encode($result);

            mysqli_close($connection);

        }
    }

?>
