<?php
require_once '../config.php';


if($connection){

    $sql = "SELECT `suspected_disease` FROM `registered_samples` GROUP BY `suspected_disease` ORDER BY count(*)";

    $respons = mysqli_query($connection, $sql);

    $result = array();
    $result['suspected_disease'] = array();

    if(mysqli_num_rows($respons)){

       while($row = mysqli_fetch_assoc($respons)){

            $index['suspected_disease'] = $row['suspected_disease'];
           
            array_push($result['suspected_disease'], $index);
       }
            
            $result['success'] = "1";
            $result['message'] = "Success";
            echo json_encode($result);
            mysqli_close($connection);
          
        }else {

            $result['success'] = "1";
            $result['message'] = "Cannot create list.";
    
            echo json_encode($result);

            mysqli_close($connection);

        }
    }

?>
