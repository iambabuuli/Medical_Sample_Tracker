<?php

require_once '../config.php';


if($_SERVER['REQUEST_METHOD'] == 'POST'){

    $suspected_disease = $_POST['suspected_disease'];
    $address = $_POST['address'];
    $results = $_POST['results'];

    $sql = "SELECT count('sample_id') AS 'sample_id' FROM registered_samples WHERE `address` = '$address' AND `suspected_disease` = '$suspected_disease' AND `results` = '$results' ";

    $respons = mysqli_query($connection, $sql);

    if(mysqli_num_rows($respons)){

        $row = mysqli_fetch_assoc($respons);

        $result['success'] = "1";
        $result['message'] = $row['sample_id'];
        echo json_encode($result);
        mysqli_close($connection);

        } else {

        $result['success'] = "0";
        $result['message'] = "Error.";
        echo json_encode($result);
        mysqli_close($connection);

        }
        
}
?>
