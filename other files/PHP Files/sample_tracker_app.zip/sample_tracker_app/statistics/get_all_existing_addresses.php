<?php
require_once '../config.php';


if($connection){

    $sql = "SELECT `address` FROM `registered_samples` GROUP BY `address` ORDER BY count(*)";

    $respons = mysqli_query($connection, $sql);

    $result = array();
    $result['address'] = array();

    if(mysqli_num_rows($respons)){

       while($row = mysqli_fetch_assoc($respons)){

            $index['address'] = $row['address'];
           
            array_push($result['address'], $index);
       }
            
            $result['success'] = "1";
            $result['message'] = "Success";
            echo json_encode($result);
            mysqli_close($connection);
          
        }else {

            $result['success'] = "1";
            $result['message'] = "Cannot create list.";
    
            echo json_encode($result);

            mysqli_close($connection);

        }
    }

?>
