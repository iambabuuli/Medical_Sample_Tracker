<?php

require_once'config.php';

if($_SERVER['REQUEST_METHOD'] == 'POST'){

        $sql = "SELECT * FROM users";

        $result = array();
        $result['users'] = array();

        $response = mysqli_query($connection, $sql);

        if(mysqli_num_rows($response)){

            while($row = mysqli_fetch_assoc($response)){

            $index['first_name'] = $row['first_name'];
            $index['last_name'] = $row['last_name'];
            $index['email'] = $row['email'];
            $index['phone_number'] = $row['phone_number'];
            $index['account_type'] = $row['account_type'];
            $index['profile_picture_path'] = $row['profile_picture_path'];
            $index['profile_picture_address'] = $row['profile_picture_address'];

            array_push($result['users'], $index);

            }

            $result['success'] = "1";
            $result['message'] ="Accounts retrived.";
            echo json_encode($result);
            mysqli_close($connection);

        }else{

            $result['success'] = "0";
            $result['message'] ="Failed to retrive accounts.";
            echo json_encode($result);
            mysqli_close($connection);

        }
    }

    ?>