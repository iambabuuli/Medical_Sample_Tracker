<?php

  require_once'config.php';
  

    if($_SERVER['REQUEST_METHOD'] == 'POST'){
    
    $id = $_POST['id'];
    $patient_id = $_POST['patient_id'];
    
    $sql = "DELETE FROM payment_of_account WHERE cash_receipt_number = '$id'";

    if(mysqli_query($connection, $sql)){

    $update_Registered_Sample = "UPDATE `registered_samples` SET paid = 'No' WHERE `patient_id` = '$patient_id' ";

    if(mysqli_query($connection, $update_Registered_Sample)){

        $result["success"] = "1";
        $result["message"] = "Successfull";

        echo json_encode($result);
        mysqli_close($connection);

    }else{

        $result["success"] = "0";
        $result["message"] = "Error";
        echo json_encode($result);
        mysqli_close($connection);

    }
        
    } else {

        $result["success"] = "0";
        $result["message"] = "Cannot delete record.";
        echo json_encode($result);
        mysqli_close($connection);

    }
}

?>
