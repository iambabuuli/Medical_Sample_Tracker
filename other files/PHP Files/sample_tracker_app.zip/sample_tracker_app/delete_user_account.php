<?php

require_once 'config.php';

 //Delete a user account from the system
    if($_SERVER['REQUEST_METHOD'] == 'POST'){

        $email = $_POST['email'];
        $profile_picture_path = $_POST['profile_picture_path'];

        if(file_exists($profile_picture_path)){

            unlink($profile_picture_path);

        $sql = "DELETE FROM users WHERE email = '$email'";

        if(mysqli_query($connection, $sql)){

            $result['success'] = "1";
            $result['message'] = "Account has been deleted.";
            echo json_encode($result);
            mysqli_close($connection);

        }else{

            $result['success'] = "0";
            $result['message'] = "Failed to delete account.";
            echo json_encode($result);
            mysqli_close($connection);
        }

        } else{

            $result['success'] = "0";
            $result['message'] = "Failed to delete profile photo.";
            echo json_encode($result);
            mysqli_close($connection);

        }
    }

 ?>