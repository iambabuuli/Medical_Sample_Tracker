<?php
require_once 'config.php';


if($_SERVER['REQUEST_METHOD'] == 'POST'){

    $sql = "SELECT * FROM received_samples";

    $respons = mysqli_query($connection, $sql);

    $result = array();
    $result['received_samples'] = array();

    if(mysqli_num_rows($respons)){

       while($row = mysqli_fetch_assoc($respons)){

            $index['sample_id'] = $row['sample_id'];
            $index['patient_id'] = $row['patient_id'];
            $index['suspected_disease'] = $row['suspected_disease'];
            $index['sample_type'] = $row['sample_type'];
            $index['sample_status'] = $row['sample_status'];
            $index['results'] = $row['results'];
            $index['registered_by'] = $row['registered_by'];
            $index['received_by'] = $row['received_by'];
            $index['registers_phone_number'] = $row['registers_phone_number'];
            $index['receivers_phone_number'] = $row['receivers_phone_number'];
            $index['lab_notes'] = $row['lab_notes'];
            $index['date_received'] = $row['date_received'];

            array_push($result['received_samples'], $index);
       }
            
            $result['success'] = "1";
            $result['message'] = "Success";
            echo json_encode($result);
            mysqli_close($connection);
          
        }
        
    } else {

        $result['success'] = "0";
        $result['message'] = "Cannot retrive data.";
    
        echo json_encode($result);
        mysqli_close($connection);

    }

?>
