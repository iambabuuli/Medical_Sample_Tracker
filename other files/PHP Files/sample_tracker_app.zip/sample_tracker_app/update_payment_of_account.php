<?php

require_once 'config.php';

//Update the records for the registered samples
if($_SERVER['REQUEST_METHOD'] == 'POST'){

    $patients_id_number = $_POST['patients_id_number'];
    $id_number = $_POST['id_number'];
    $surname = $_POST['surname'];
    $first_name = $_POST['first_name'];
    $title = $_POST['title'];
    $postal_address = $_POST['postal_address'];
    $telephone_number = $_POST['telephone_number'];
    $email= $_POST['email'];
    $employer = $_POST['employer'];
    $medical_aid_name = $_POST['medical_aid_name'];
    $cash_receipt_number = $_POST['cash_receipt_number'];
    
   
    $sql = "UPDATE `payment_of_account` SET `patient_id`= '$patients_id_number', `national_id_number`= '$id_number', `first_name`= '$surname', `last_name`= '$first_name',`title`= '$title', `postal_address`= '$postal_address', `phone_number` = '$telephone_number', `email` = '$email' ,`employer` = '$employer', `medical_aid_name` = '$medical_aid_name', `cash_receipt_number` = '$cash_receipt_number' WHERE `cash_receipt_number` = '$cash_receipt_number'";

    if( mysqli_query($connection, $sql)){

        $result["success"] = "1";
        $result["message"] = "Successfull";

        echo json_encode($result);
        mysqli_close($connection);

    }else{

        $result["success"] = "0";
        $result["message"] = "Cannot update.";

        echo json_encode($result);
        mysqli_close($connection);

    }
}

?>