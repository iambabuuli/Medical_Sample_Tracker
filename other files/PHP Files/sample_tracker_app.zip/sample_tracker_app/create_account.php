<?php

  require_once'config.php';
  

    if($_SERVER['REQUEST_METHOD'] == 'POST'){
    
    
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $email = $_POST['email'];
    $phone_number = $_POST['phone_number'];
    $password = $_POST['password'];
    $account_type = $_POST['account_type'];
    $encoded_photo = $_POST['encoded_photo'];
    $image_name = $_POST['image_name'];

    $image_path = "profile_pictures/".$image_name;

    $final_image_path = $address."sample_tracker_app/".$image_path;
    
    $final_password = password_hash($password, PASSWORD_DEFAULT);


    if(file_put_contents($image_path, base64_decode($encoded_photo))){

    $sql = "INSERT INTO `users`(`first_name`, `last_name`, `email`, `phone_number`, `password`, `account_type`, `profile_picture_path`, `profile_picture_address`) VALUES ('$first_name', '$last_name', '$email', '$phone_number', '$final_password', '$account_type', '$image_path', '$final_image_path')";

    if(mysqli_query($connection, $sql)){

        $result["success"] = "1";
        $result["message"] = "Account created.";

        echo json_encode($result);
        mysqli_close($connection);

    }else{

        $result["success"] = "0";
        $result["message"] = "Failed to create account.";

        echo json_encode($result);
        mysqli_close($connection);

    }

    } else {

        $result["success"] = "0";
        $result["message"] = "Cannot create profile photo.";

        echo json_encode($result);
        mysqli_close($connection);
         
    }

}

?>
