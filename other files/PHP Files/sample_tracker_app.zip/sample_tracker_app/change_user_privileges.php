<?php 

require_once 'config.php';

 //Change the user previleges 
    if($_SERVER['REQUEST_METHOD'] == 'POST'){

        $email = $_POST['email'];
        $account_type = $_POST['account_type'];
        
        $sql = "UPDATE users SET account_type = '$account_type' WHERE email = '$email'";

        if(mysqli_query($connection, $sql)){

            $result['success'] = "1";
            $result['message'] = "Account updated.";
            echo json_encode($result);
            mysqli_close($result);

        }else{

            $result['success'] = "0";
            $result['message'] = "Failed to update account.";
            echo json_encode($result);
            mysqli_close($connection);

        }
    }
?>